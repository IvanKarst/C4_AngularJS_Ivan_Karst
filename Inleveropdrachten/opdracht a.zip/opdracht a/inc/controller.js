angular.module('myApp', []).controller('myCtrl', function($scope, defaults) {
	console.log('chess');
	$scope.defaults = angular.copy(defaults.defaults);
	$scope.formData = [];
	$scope.info = [];

	$scope.updateData = function ($myCtrl) {
		var defaultValues = $scope.defaults[0];  // Accessing the first (and only) element in the array
	
		$scope.info.push({
			firstName: $scope.formData.firstName || defaultValues.firstName,
			lastName: $scope.formData.lastName || defaultValues.lastName,
			streetName: $scope.formData.streetName || defaultValues.streetName,
			housenumber: $scope.formData.housenumber || defaultValues.housenumber,
			postalCode: $scope.formData.postalCode || defaultValues.postalCode,
			residency: $scope.formData.residency || defaultValues.residency,
			emailadress: $scope.formData.emailadress || defaultValues.emailadress
		});
	};	
});