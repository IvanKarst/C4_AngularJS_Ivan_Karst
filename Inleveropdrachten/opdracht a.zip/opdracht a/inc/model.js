angular.module('myApp', []).factory('defaults', function () {
	console.log("defaults_check");
	return {
		defaults: [
			{
				firstName: 'John',
				lastName: 'Doe',
				streetName: 'Homestreet',
				housenumber: '123ab',
				postalCode: '1234 AB',
				residency: 'Cheese',
				emailadress: 'john@example.com',
			}
		]
	};
});