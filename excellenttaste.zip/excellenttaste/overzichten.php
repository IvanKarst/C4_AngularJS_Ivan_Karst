<?php

require_once("includes/includes.php");
require_once(CLASSES_PATH . "table.inc.php");	
	
class clsOverzicht extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
                   
          $vandaag = date("Y-m-d");
          $this->selectsql = "SELECT r.tafel AS tafelnr, 
                                     b.aantal AS aantalitems, 
                                     m.menuitemnaam AS naam, 
                                     r.reservering_id AS res_id 
                                   FROM reservering r
                                   LEFT JOIN bestelling b 
                                     ON r.reservering_id = b.reservering_id
                                   LEFT JOIN menuitem m 
                                     ON b.menuitemcode = m.menuitemcode
                                   LEFT JOIN subgerecht s 
                                     ON m.subgerechtcode = s.subgerechtcode 
                                   WHERE r.datum = '$vandaag'  
                                     ";         // Gewijzigd n.a.v. ticketnummer [[330]]     
          $this->tablename = "reservering";
          $this->key = "res_id";
          $this->setReadOnly(true);
          
          $column = new clsColumn();
          $column->setFieldName("tafelnr");
          $column->setCaption("Tafel");         
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("aantalitems");
          $column->setCaption("Aantal");         
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("naam");
          $column->setCaption("Gerecht");
          $this->columnHeader->addColumn($column);
     } 
}

class clsOverzichtKok extends clsOverzicht
{
     public function getSelectSql()
     { // Overwrite
          return $this->selectsql .= "AND s.gerechtcode <> 'drk'"; // Gewijzigd n.a.v. ticketnummer [[330]]  
     }
}

class clsOverzichtOber extends clsOverzicht
{     
     public function getSelectSql()
     { // Overwrite
          return $this->selectsql .= "AND s.gerechtcode = 'drk'"; // Gewijzigd n.a.v. ticketnummer [[330]]    
     }
}

class clsPage extends clsDefaultPage
{
     protected function contentHtml()
     {			
          if (isset($_GET['overzicht'])) 
          {
               return $this->getOverzicht($_GET['overzicht']);
          }
          return "";
     }
     
     protected function getOverzicht($voorWie) 
     {    // Gewijzigd n.a.v. ticketnummer [[330]]     
          if ($voorWie == "kok")
          {    $datalist = new clsOverzichtKok();
          }
          else
          {    if ($voorWie == "barman")
               {    $datalist = new clsOverzichtOber();
               }
               else
               {    $datalist = new clsOverzicht();
               }
          }
          // Einde gewijzigd n.a.v. ticketnummer [[330]] 
          return $datalist->getGridHtml();
     }
}
     
     $page = new clsPage();
	echo $page->getHtml();
	
?>