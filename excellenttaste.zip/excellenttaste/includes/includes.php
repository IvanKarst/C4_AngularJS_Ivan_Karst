<?php
	require_once("config/config.inc.php");
	require_once(CLASSES_PATH . "page.inc.php");	
?>