<?php
require_once("includes/includes.php");
require_once(CLASSES_PATH . "table.inc.php");	

class clsBestelling 
{
     public function __construct() 
     {
          //Call the databaseconnection
          $this->connection = database::connect();
     }
     
     public function getBestelling() 
     {
          if (isset($_GET['reservering'])) 
          {
               $_SESSION['bestellingen']['reserverings_id'] = $_GET['reservering'];
          }
          if (isset($_GET['action'])) 
          {
               $action = $_GET['action'];
               switch($action) 
               {
                    case "plusitem"	: $this->plusitem(); break;
                    case "minitem"		: $this->minitem(); break;
                    case "deleteitem"	: $this->deleteitem(); break;
               }
               
          }
          
          if (isset($_SESSION['bestellingen']['reserverings_id'])) 
          {
               if ($_SESSION['bestellingen']['reserverings_id'] > 0) 
               {
                    $tafelnummer = $this->getTafelnummer();
                    return $tafelnummer . $this->currentBestelling();
               }
          }
     }
     
     protected function getTafelnummer() 
     {
          if (Isset($_GET['tafelnummer'])) 
          {
               if ($_GET['tafelnummer'] > 0) 
               {
                    $_SESSION['bestellingen']['tafelnummer'] = $_GET['tafelnummer'];
               }
          }
          $output = "Neem bestelling op voor tafel " . $_SESSION['bestellingen']['tafelnummer'];
          return $output;
     }
     
     private function getCurrentAantal() 
     {
          $reservering_id 	= $_GET['reservering'];
          $menuitemcode 		= $_GET['menuitemcode'];
          $sql 			= "SELECT aantal FROM bestelling 
                                 WHERE reservering_id = $reservering_id 
                                   AND menuitemcode = '$menuitemcode'";
                              
          $stmt			= $this->connection->prepare($sql); 
          $stmt->execute(); 
          $row 		     = $stmt->fetch();												
          $aantal 			= $row['aantal'];
          return $aantal;
     }
     
     
     private function plusitem() 
     {
          $reservering_id = $_GET['reservering'];
          $menuitemcode = $_GET['menuitemcode'];
                         
          $aantal = $this->getCurrentAantal();
          $aantal++;
          
          $sql = "UPDATE bestelling SET aantal = $aantal 
                  WHERE reservering_id = $reservering_id 
                    AND menuitemcode = '$menuitemcode'";
          if ($this->connection->query($sql) == true) 
          {
               return;
          } 
          else 
          {
               print $sql . " Mislukt"; die;
          }							
     }
     
     private function minitem() 
     {
          $reservering_id = $_GET['reservering'];
          $menuitemcode = $_GET['menuitemcode'];
                         
          $aantal = $this->getCurrentAantal();
          if ($aantal > 1) 
          {
               $aantal--;
          } 
          // Toegevoegd n.a.v. ticketnummer [[334]]
          else           
          { 
               if ($aantal == 1)
               {    $this->deleteitem();
               }
               return;
          } 
          // Einde toegevoegd n.a.v. ticketnummer [[334]]
          
          $sql = "UPDATE bestelling SET aantal = $aantal 
                  WHERE reservering_id = $reservering_id 
                    AND menuitemcode = '$menuitemcode'";
          if ($this->connection->query($sql) == true) 
          {
               return;
          } 
          else 
          {
               print $sql . " Mislukt"; die;
          }			
     }
     
     private function deleteitem() 
     {
          $reservering_id = $_GET['reservering'];
          $menuitemcode = $_GET['menuitemcode'];
          
          $sql = "DELETE FROM bestelling 
                   WHERE reservering_id = $reservering_id 
                     AND menuitemcode = '$menuitemcode'";
          if ($this->connection->query($sql) == true) 
          {
               return;
          } 
          else 
          {
               print $sql . " Mislukt"; die;
          }
     }
     
     
     private function currentBestelling() 
     {
          $reserveringsID = $_SESSION['bestellingen']['reserverings_id'];
          
          $sql = "SELECT * FROM bestelling b, menuitem m 
                   WHERE b.reservering_id = $reserveringsID
                     AND b.menuitemcode = m.menuitemcode";

          $output = "
               <table>
                    <thead>
                         <tr>
                              <th>Artikel:</th>
                              <th>#</th> " . 
                              // Gewijzigd n.a.v. Ticketnummer [[341]]
                             "<th>Prijs</th>  
                              <th>Totaal</th>
                              <th></th>
                              <th></th>
                              <th></th>" .
                              // Eindeewijzigd n.a.v. Ticketnummer [[341]]
                        "</tr>
                    </thead>
                    <tbody>";
                    $disableprint = -1; // Toegevoegd n.a.v. Ticketnummer [[354]]
                    $som = 0; // Toegevoegd n.a.v. Ticketnummer [[341]]
                    foreach ($this->connection->query($sql) as $row) 
                    {
                         $disableprint = 1; // Toegevoegd n.a.v. Ticketnummer [[354]]
                         $menuitemcode = $row['menuitemcode'];
                         $som += $row['prijs'] * $row['aantal']; // Toegevoegd n.a.v. Ticketnummer [[341]]
                         $output .= "
                         <tr>
                              <td>" . $row['menuitemnaam'] . "</td>
                              <td>" . $row['aantal'] . "</td>" .
                              // Toegevoegd n.a.v. Ticketnummer [[341]]
                             "<td class='text-right'>&euro;&nbsp;" . 
                                   number_format($row['prijs'], 2, ',','.') . "</td>
                              <td class='text-right'>&euro;&nbsp;" . 
                                   number_format($row['prijs'] * $row['aantal'], 2, ',','.') . "</td>" .
                              // Einde toegevoegd n.a.v. Ticketnummer [[341]]
                             "<td>
                                   <a href='bestellingen.php?action=plusitem&menuitemcode=" . $menuitemcode .
                                                           "&reservering=$reserveringsID'>
                                        <i class='fa fa-plus-circle' aria-hidden='true'></i>
                                   </a>
                              </td>
                              <td>
                                   <a href='bestellingen.php?action=minitem&menuitemcode=" . $menuitemcode .
                                                           "&reservering=$reserveringsID'>
                                        <i class='fa fa-minus-circle' aria-hidden='true'></i>
                                   </a>
                              </td>
                              <td>
                                   <a href='bestellingen.php?action=deleteitem&menuitemcode=" . $menuitemcode .
                                                           "&reservering=$reserveringsID'>
                                        <i class='fa fa-trash-o' aria-hidden='true'></i>
                                   </a>
                              </td>
                         </tr>";
                    }
          // Toegevoegd n.a.v. Ticketnummer [[341]]
          $output .= "   <tr>
                              <td class='text-right' colspan='2'><h5>Totaal</h5></td>
                              <td class='text-right' colspan='2'>&euro;&nbsp;" . number_format($som, 2, ',','.') . "</td>
                         </tr>";
          // Einde toegevoegd n.a.v. Ticketnummer [[341]]
          $output .= "
                    </tbody>
               </table>
               <br />
               <a href='bon.php?reservering=$reserveringsID' 
                  class='btn btn-default "; 
         // Toegevoegd n.a.v. Ticketnummer [[354]]
         if ($disableprint < 0)
         {    $output .= 'invisible';
         }
         // Einde toegevoegd n.a.v. Ticketnummer [[354]]
         $output .= 
               "' target='_blank'>Print bon voor klant
               </a>";
          return $output;        
     }
}	


class clsPage extends clsDefaultPage
{
     
     public function contentHtml() 
     {
          if (isset($_GET['action'])) 
          {
               if ($_GET['action'] == "nieuw") 
               {
                    $_SESSION['bestellingen']['tafelnummer'] = '-1';
                    header("Location: bestellingen.php");
               }
               
               if ($_GET['action'] == "add") 
               {
                    $this->save();
                    header("Location: bestellingen.php");				
               }
          }
          $bestelling = new clsBestelling;
          $output = '
               <div class="col-xs-6 col-sm-6 col-lg-6">' .
               $bestelling->getBestelling() .
              '</div>
               <div class="col-xs-6 col-sm-6 col-lg-6">' .
                    $this->getGerecht() .
              '</div>';
          return $output;
     }
     
     protected function getMenuitem($menuitemcode) 
     {
          $sql = "SELECT * FROM menuitem WHERE menuitemcode = '$menuitemcode'";
          foreach ($this->connection->query($sql) as $row) 
          {
               $aOutput = $row;
          }
          return $aOutput;
     }
     
     
     protected function save() 
     {
          // insert one row
          $tafel 			= $_SESSION['bestellingen']['tafelnummer'];
          $reservering_id	= $_SESSION['bestellingen']['reserveringsnummer'];
          $datum 			= date("Y-m-d");
          $tijd 			= date("H:i:s");
          $menuitemcode 		= $_GET['item'];
          $aMenuitem 		= $this->getMenuitem($menuitemcode);
          $aantal 			= 1;
          $prijs 			= $aMenuitem['prijs'];
          
          // Toegevoegd n.a.v. ticketnummer [[340]]
          $sql = "SELECT COUNT(*) AS aantal 
                    FROM bestelling 
                   WHERE (reservering_id = " . $reservering_id . ") 
                     AND (menuitemcode = '" . $menuitemcode . "')";
          if ($this->connection->query($sql)->fetchColumn() > 0)
          {    $sql = "UPDATE bestelling SET aantal = aantal + 1
                        WHERE reservering_id = $reservering_id 
                        AND menuitemcode = '$menuitemcode'";
               if ($this->connection->query($sql) == true) 
               {
                    return;
               } 
               else 
               {
                    print $sql . " Mislukt"; die;
               }
          }
          // Einde toegevoegd n.a.v. ticketnummer [[340]]
          
          $sql = "INSERT INTO bestelling 
                              (reservering_id, tafel, datum, tijd, menuitemcode, aantal, prijs) 
                       VALUES ($reservering_id, $tafel, '$datum', '$tijd', '$menuitemcode', $aantal, $prijs)";
                         
          if (!($this->connection->query($sql) == true)) 
		{    print $sql . " Mislukt"; 
		     die;
		}							
     }
     
     protected function getGerecht() 
     {
          $output = "";
          //GERECHT
          
          foreach($this->connection->query('SELECT * FROM gerecht') as $rowgerecht) 
          {
              $output .= 
                   "<div class='row'><h3>" . $rowgerecht['gerechtnaam'] . "</h3>";
                         
              //SUBGERECHT
              foreach ($this->connection->query('SELECT * FROM subgerecht') as $rowsubgerecht) 
              {
                   if ($rowgerecht['gerechtcode'] == $rowsubgerecht['gerechtcode']) 
                   {
                        $output .= "
                        <div class='col-xs-4 col-md-4'><h5>" . $rowsubgerecht['subgerechtnaam'] . "</h5>";
                         
                        //MENUITEM
                        foreach ($this->connection->query('SELECT * FROM menuitem') as $rowmenuitem) 
                        {
                             if ($rowsubgerecht['subgerechtcode'] == $rowmenuitem['subgerechtcode']) 
                             {
                                  $output .= "
                              <a href='?action=add&item=" . $rowmenuitem['menuitemcode'] ."'>"
                               . $rowmenuitem['menuitemnaam']
                           . "</a><br>";
                             }
                        }   	
                        $output .= "
                              </div>"; //end div subgerecht
                   }
              }
              $output .= "
                    </div>"; //end div gerecht
          }			
          return $output;
     }		
}
     $page = new clsPage();
	echo $page->getHtml();

?>