<?php

require_once("includes/includes.php");
require_once(CLASSES_PATH . "table.inc.php");	

class clsPage extends clsDefaultPage
{
     protected function contentHtml() 
     {			
          if (isset($_GET['action'])) 
          {
               $action = $_GET['action'];
               switch($action) 
               {
                    case "add":       $output = $this->add(); break;
                    case "edit":      $output = $this->edit(); break;
                    case "save":      $output = $this->save(); break;
                    case "delete":    $output = $this->delete(); break;
                    case "bestellen": $output = $this->bestellen(); break;
               }
          } 
          else 
          {
               $output = $this->getReserveringen();
          }
          return $output;
     }
     
     private function add() 
     {    $klantId = -1;
          if (isset($_POST['inputklanten'])) 
          {
               $klantId = $_POST['inputklanten'];
          }
          $row = $this->getKlantVars($klantId); 
          $rowreservering = $this->getReserveringVars(-1);
          $row = array_merge($row, $rowreservering);

          $output = "
               <form action='?action=add' method='post' enctype='multipart/form-data'>

                    <label>Selecteer klant
                    </label>
                    
                    <select id='inputklanten' name='inputklanten'>" .
                         $this->getKlanten() . "                         
                    </select> 
                     
                    <input type='submit' name='submit_klantselecteren' 
                           id='submit_klantselecteren' value='Selecteer klant'/>
               </form>" . $this->showReserveringForm($row);
          
          return $output;	
     }
     
     protected function edit()
     {
          $reserveringId = -1;
          if (isset($_GET['reservering'])) 
          {
               $reserveringId = $_GET['reservering'];
          }
          
          $row = $this->getReserveringVars($reserveringId); 
          $klantId = $row['klant_id'];
          $rowklant = $this->getKlantVars($klantId); 
          $row = array_merge($row, $rowklant);
          
          $output = $this->showReserveringForm($row);
         
          return $output;
     }
     
     // Toegevoegd n.a.v. ticketnummer [[331]] 
     private function validateDateTime($date, $time)
     {    $format = 'd-m-Y H:i';
          $input = $date . " " . $time;
          $datum = DateTime::createFromFormat($format, $input);
          return $datum && $datum->format($format) == $input;
     }
     // Einde toegevoegd n.a.v. ticketnummer [[331]]               
     
     private function save() 
     {
          $tafel  = $_POST['tafelnummer'];
          $datum  = $_POST['reserveringsdatum'];         
          
          $tijd   = $_POST['reserveringstijd'];
          $aantal = $_POST['aantal'];
          $aantal_k = $_POST['aantal_k']; // Toegevoegd n.a.v. ticketnummer [[335]] 
          $allergieen = $_POST['allergieen']; // Toegevoegd n.a.v. ticketnummer [[336]] 
          $opmerkingen = $_POST['opmerkingen']; // Toegevoegd n.a.v. ticketnummer [[338]]
          
          // Toegevoegd n.a.v. ticketnummer [[331]] 
          if (!$this->validateDateTime($datum, $tijd))
          {    die('Ongeldige datum/tijd.'); 
          }							
          // Einde toegevoegd n.a.v. ticketnummer [[331]]               
               
          $reservering_id = -1;
          if (isset($_POST['reserveringId'])) 
          {
               $reservering_id = $_POST['reserveringId'];
          }
          //check of de klant nieuw is of al bestaat	
          $klant_id	= $this->saveNewCustomer($_POST['klantId']);
          //de datum moet omgedraaid worden voordat die opgeslagen wordt
          $datum  = $this->convertDateSQLFormat($datum, -1);
                    
          if ($reservering_id < 0)
          {
               $sql = "INSERT INTO reservering 
                                   (tafel, datum, tijd, klant_id, aantal, aantal_k, allergieen, opmerkingen) 
                                   VALUES 
                                   ($tafel, '$datum', '$tijd', $klant_id, 
                                    $aantal, $aantal_k, '$allergieen', '$opmerkingen')"; // Gewijzigd n.a.v. ticketnummer [[335]] 
                                                                                         // Gewijzigd n.a.v. ticketnummer [[336]]
                                                                                         // Gewijzigd n.a.v. ticketnummer [[338]]
          }
          else
          {
               $sql = "UPDATE reservering  
                          SET tafel = $tafel, datum = '$datum', tijd = '$tijd', aantal = $aantal,
                                      aantal_k = $aantal_k, allergieen = '$allergieen', opmerkingen = '$opmerkingen'
                        WHERE reservering_id = $reservering_id"; // Gewijzigd n.a.v. ticketnummer [[335]]
                                                                 // Gewijzigd n.a.v. ticketnummer [[336]]
                                                                 // Gewijzigd n.a.v. ticketnummer [[338]]
          }
          if ($this->connection->query($sql) == true) 
          {    header("Location: reserveringen.php");
		} 
		else 
		{    print $sql . " Mislukt"; die;
		}							
     }   

     protected function delete() 
     {
          $reservering_id = -1;
          if (isset($_GET['reservering'])) 
          {
               $reservering_id = $_GET['reservering'];
          }
          
          // Toegevoegd n.a.v. ticketnummer [[350]]
          $sql = "SELECT COUNT(*) 
                    FROM bestelling            
                   WHERE reservering_id = " . $reservering_id;
          if ($this->connection->query($sql)->fetchColumn() > 0)
          {    $output = 
                   "<div class='row'>
                         <div class='help-block'>
                         </div>
                         <div class='centered'>
                              <label for='okdialog_id'>Er zijn bestellingen voor deze reservering.<br>
                                                       Deze reservering mag daarom niet worden verwijderd.
                              </label>                   
                              <div class='help-block'>
                              </div>
                              <a href='reserveringen.php' 
                                 id='okdialog_id' 
                                 class='btn btn-primary'>Ok
                              </a>
                         </div>
                   </div>";
    
              return $output;
          }
          // Einde toegevoegd n.a.v. ticketnummer [[350]]
          $sql = "DELETE FROM reservering  
                   WHERE reservering_id = $reservering_id";
                   
          if ($this->connection->query($sql) == true) 
          {    header("Location: reserveringen.php");
		} 
		else 
		{    print $sql . " Mislukt"; die;
		}							
     }
     
     protected function bestellen() 
     {
          if(isset($_GET['reservering'])) 
          {
               if($_GET['reservering'] > 0) 
               {
                    $reserveringsnummer = $_GET['reservering'];
                    $_SESSION['bestellingen']['reserveringsnummer'] = $reserveringsnummer;
                    
                    $sql = "SELECT tafel FROM reservering 
                                   WHERE reservering_id = '$reserveringsnummer'";

                    foreach($this->connection->query($sql) as $row) 
                    {
                         $_SESSION['bestellingen']['tafelnummer'] = $row['tafel'];
                    }
                    header("Location: bestellingen.php?reservering=$reserveringsnummer");
               }
          }
     }
     
     private function getKlanten() 
     {
          $sql = "SELECT klant_id, klantnaam FROM klant
                  WHERE status = '1'";
          $output = "<option id='-1' value='-1'>--Nieuwe klant--</option>";
          foreach($this->connection->query($sql) as $row) 
          {
               $output .= "<option id='" . $row['klant_id'] . "' value='" . 
                          $row['klant_id'] . "'> " . $row['klantnaam'] ."</option>";
          }
          return $output;
     }
     
     private function getKlantVars($klantId) 
     {
          if ($klantId > -1)
          {
               $sql = "SELECT klant_id, klantnaam, email, telefoon FROM klant
                       WHERE klant_id = $klantId 
                         AND status = '1'";
               $stmt = $this->connection->prepare($sql); 
               $stmt->execute(); 
               $row	= $stmt->fetch();												
          }
          else
          {    // Nieuwe klant
               $row['klantnaam']	= "";
               $row['email']		= "";
               $row['klant_id']	= -1;
               $row['telefoon']	= "";
          }
          return $row;			
     }
     
     private function getReserveringVars($reserveringId) 
     {
          if ($reserveringId > -1)
          {
               $sql = "SELECT reservering_id, tafel, datum, tijd, klant_id, 
                              aantal, aantal_k, allergieen, opmerkingen 
                        FROM reservering
                       WHERE reservering_id = $reserveringId 
                         AND status = '1'";  // Gewijzigd n.a.v. ticketnummer [[335]] 
                                             // Gewijzigd n.a.v. ticketnummer [[336]]
                                             // Gewijzigd n.a.v. ticketnummer [[338]]
               $stmt = $this->connection->prepare($sql); 
               $stmt->execute(); 
               $row	= $stmt->fetch();
               $row['datum'] = $this->convertDateSQLFormat($row['datum'], 1);
               $d = date_create("10-10-2010 " . $row['tijd']);               
               $row['tijd'] = date_format($d,"H:i");
          }
          else
          {    // Nieuwe reservering
               $row['reservering_id'] = -1;
               $row['datum']	        = date("d-m-Y");  // Gewijzigd n.a.v. ticketnummer [[329]]               
               $row['tijd']	        = "";
               $row['tafel']	        = "";
               $row['aantal']	        = "";
               $row['aantal_k']       = 0;  // Toegevoegd n.a.v. ticketnummer [[335]] 
               $row['allergieen']	   = ""; // Toegevoegd n.a.v. ticketnummer [[336]]
               $row['opmerkingen']	   = ""; // Toegevoegd n.a.v. ticketnummer [[338]]
          }
          return $row;			
     }   
     
     private function showReserveringForm($row)
     {    $dis_html = "disabled";
          if ($row['klant_id'] < 0)
          {
               $dis_html = "";
          }
          // Gewijzigd n.a.v. ticketnummer [[357]]
          $divclass = "class='form-group col-xs-10 col-sm-3 col-md-3 col-lg-3'";
          $output = "
               <form action='?action=save' method='post' enctype='multipart/form-data' role='form'>
                    <input type='hidden' name='klantId' id='klantId' value='" . $row['klant_id'] . "' />
                    <input type='hidden' name='reserveringId' id='reserveringId' value='" . $row['reservering_id'] . "' />
                    <div $divclass>
                         <label>Klantnaam</label>
                         <input type='text' name='klantnaam' id='klantnaam' class='form-control' 
                                $dis_html value='" . $row['klantnaam'] . "' />
                    </div>
                    <div $divclass>
                         <label>E-mailadres klant</label>
                         <input type='text' name='email' id='email' class='form-control' 
                                $dis_html value='" . $row['email'] . "'/>
                    </div>
                    <div $divclass>
                         <label>Telefoonnummer klant</label>
                         <input type='text' name='telefoon' id='telefoon' class='form-control' 
                                $dis_html value='" . $row['telefoon'] . "'/>
                    </div>
                    <div $divclass>
                         <label>Reserveringsdatum (dd-mm-jjjj)</label>
                         <input type='text' name='reserveringsdatum' id='reserveringsdatum' 
                                class='form-control' 
                                value='" . $row['datum'] . "'/>
                    </div>
                    <div $divclass>
                         <label>Reserveringstijd (uu:mm)</label>
                         <input type='text' name='reserveringstijd' id='reserveringstijd' 
                                class='form-control' 
                                value='" . $row['tijd'] . "' />
                    </div>
                    <div $divclass>
                         <label>Tafelnummer</label>
                         <input type='number' name='tafelnummer' id='tafelnummer' min='1' max='10' 
                                class='form-control' 
                                value='" . $row['tafel'] . "' />
                    </div>
                    <div $divclass>
                         <label>Aantal personen</label>
                         <input type='text' name='aantal' id='aantal' class='form-control' 
                                value='" . $row['aantal'] . "' />
                    </div>";
          $output .= "
                    <div $divclass>
                         <label>Waarvan kinderen</label>
                         <input type='text' name='aantal_k' id='aantal_k' class='form-control' 
                                value='" . $row['aantal_k'] . "' />
                    </div>"; // Toegevoegd n.a.v. ticketnummer [[335]]
          $output .= "
                    <div $divclass>
                         <label>Allergie&#235;n</label>
                         <textarea name='allergieen' id='allergieen' class='form-control'>" . 
                              $row['allergieen'] . 
                        "</textarea>
                    </div>"; // Toegevoegd n.a.v. ticketnummer [[336]]
          $output .= "
                    <div $divclass>
                         <label>Opmerkingen</label>
                         <textarea name='opmerkingen' id='opmerkingen' class='form-control'>" . 
                              $row['opmerkingen'] . 
                        "</textarea>
                    </div>"; // Toegevoegd n.a.v. ticketnummer [[338]]
          $output .= "
                    <div $divclass>
                         <input type='submit' name='submit' id='submit' value='Opslaan' />
                    </div>
               </form>";
          // Einde gewijzigd n.a.v. ticketnummer [[357]]
          return $output;
     }
     
     private function saveNewCustomer($klant_id) 
     {
          $id = $klant_id;
          if ($id < 0)
          {    //save customer first and return klant_id
               $klantnaam 	= $_POST['klantnaam'];
               $email 		= $_POST['email'];
               $telefoon	     = $_POST['telefoon'];
               
               // Toegevoegd n.a.v. ticketnummer [[351]]               
               if ($klantnaam == "")
               {    die('Vul minstens de klantnaam in.'); 
               }							
               // Einde toegevoegd n.a.v. ticketnummer [[351]]   
               
               $sql = "INSERT INTO klant 
                                   (klantnaam, email, telefoon) 
                              VALUES 
                                   (:klantnaam, :email, :telefoon)";
                    
               $stmt = $this->connection->prepare($sql);
               $stmt->bindParam(':klantnaam', $klantnaam);
               $stmt->bindParam(':email', $email);
               $stmt->bindParam(':telefoon', $telefoon);
               // Gewijzigd n.a.v. ticketnummer [[351]]
               if ($stmt->execute() == true)
               {    $id = $this->connection->lastInsertId();
               } 
               else 
               {    die($sql . " is mislukt. De gegevens zijn NIET opgeslagen"); 
               }	
               // Gewijzigd n.a.v. ticketnummer [[351]]
          }
          return $id; //if not new saved klant, then return existed klant_id
     }
     
     private function convertDateSQLFormat($datum, $toSQL) 
     {
          if ($toSQL < 0)
          {
               // 15-02-2017 to 2017-02-15
               $dag 	= substr($datum, 0, 2);
               $maand 	= substr($datum, 3, 2);
               $jaar	= substr($datum, 6, 4);
               $output = $jaar . "-" . $maand . "-" . $dag;
          }
          else
          {
               // 2017-02-15 to 15-02-2017
               $jaar 	= substr($datum, 0, 4);
               $maand 	= substr($datum, 5, 2);
               $dag	= substr($datum, 8, 2);
               $output = $dag . "-" . $maand . "-" . $jaar;
          }
          return $output;
     }
         
     protected function getReserveringen() 
     {
          $output = '<p>Klik op het tafelnummer om een bestelling te maken.</p>';
          $output .= '| rood = verleden | groen = vandaag | oranje = toekomst |';
          $output .= '<table>';
               $output .= '<thead>';
                    $output .= '<tr>';
                         $output .= '<th>Datum</th>';
                         $output .= '<th>Tijd</th>';
                         $output .= '<th>Tafel</th>';
                         $output .= '<th>Klantnaam</th>';
                         $output .= '<th>Telefoonnummer</th>';
                         $output .= '<th>Aantal</th>';
                         $output .= '<th>
                                          <a href="?action=add">
                                               <i class="fa fa-plus" aria-hidden="true"></i>
                                          </a>
                                     </th>';
                         $output .= '<th></th>';
                    $output .= '</tr>';
               $output .= '</thead>';
               
               $output .= '<tbody>';

                    $sql = "SELECT * FROM reservering r, klant k 
                            WHERE r.klant_id = k.klant_id
                              AND r.status = '1'
                            ORDER BY datum, tijd";

                    foreach($this->connection->query($sql) as $row) {
                         
                         $class = "";
                         if($row['datum'] > date("Y-m-d")) { $class = "toekomst"; }
                         if($row['datum'] == date("Y-m-d")) { $class = "vandaag"; }
                         if($row['datum'] < date("Y-m-d")) { $class = "verleden"; }
                         
                         $output .= "<tr class='$class'>";
                              $output .= "<td>";
                                   //Rotate date from sql to dutch notation
                                   $datum 	= $row['datum'];
                                   $dag 	= substr($datum, 8, 2);
                                   $maand 	= substr($datum, 5, 2);
                                   $jaar 	= substr($datum, 0, 4);
                                   $datum 	= $dag . "-" . $maand . "-" . $jaar;
                                   
                                   $output .= $datum;
                              $output .= "</td>";
                              
                              $output .= "<td>";
                                   $output .= substr($row['tijd'],0,5); //We only need hours and seconds
                              $output .= "</td>";
                              
                              $output .= "<td class='td_tafel'>";
                                   $output .= "<a href='?action=bestellen&reservering=" . $row['reservering_id'] . " '>" . $row['tafel'] . "</a>";
                              $output .= "</td>";

                              
                              $output .= "<td>";
                                   $output .= $row['klantnaam'];
                              $output .= "</td>";
                              
                              $output .= "<td>";
                                   $output .= $row['telefoon'];
                              $output .= "</td>";
                              
                              $output .= "<td>";
                                   $output .= $row['aantal'];
                              $output .= "</td>";
                              
                              $output .= "<td>";
                                   $output .= "<a href='?action=edit&reservering=" . 
                                              $row['reservering_id']."'><i class='fa fa-pencil'></i></a>";
                              $output .= "</td>";

                              $output .= "<td>";
                                   $output .= "<a href='?action=delete&reservering=" . 
                                              $row['reservering_id']."'><i class='fa fa-trash-o'></a>";
                              $output .= "</td>";

                         $output .= "</tr>";
                    }
          
          $output .= "</tbody>";
          $output .= "</table>";
          return $output;
     }	
}
     $page = new clsPage();
	echo $page->getHtml();

?>