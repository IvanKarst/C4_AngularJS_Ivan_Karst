<?php
	require_once("includes/includes.php");
     require_once(CLASSES_PATH . "table.inc.php");	
	
class clsDrinkenEnEten extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = ""; // is set in derived class
          $this->tablename = "menuitem";
          $this->key = "menuitemcode";
          
          $column = new clsColumn();
          $column->setFieldName("menuitemcode");
          $column->setCaption("Code");         
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("menuitemnaam");
          $column->setCaption("Omschrijving");         
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("prijs");
          $column->setCaption("Prijs");
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("subgerechtcode");
          $column->setCaption("Valt onder");
          $column->setEditType("Select");
          $column->setLookUpSql("SELECT CONCAT(s.subgerechtcode, ' - ', s.subgerechtnaam, '->', g.gerechtnaam) as lookupresult,
                                        s.subgerechtcode as lookup_id
                                   FROM subgerecht s 
                                   LEFT JOIN gerecht g 
                                          ON s.gerechtcode = g.gerechtcode");
          $this->columnHeader->addColumn($column);         
     }  
}

class clsDrinken extends clsDrinkenEnEten
{
     public function __construct() 
     {
          parent::__construct();

          $this->selectsql = "SELECT m.menuitemnaam, m.menuitemcode, m.prijs, m.subgerechtcode    
                                FROM menuitem m 
                                LEFT JOIN subgerecht s 
                                       ON m.subgerechtcode = s.subgerechtcode
                              WHERE s.gerechtcode = 'drk'";
     }      
}

class clsEten extends clsDrinkenEnEten
{     
     public function __construct() 
     {
          parent::__construct();

          $this->selectsql = "SELECT m.menuitemnaam, m.menuitemcode, m.prijs, m.subgerechtcode  
                                FROM menuitem m 
                                LEFT JOIN subgerecht s 
                                       ON m.subgerechtcode = s.subgerechtcode
                              WHERE s.gerechtcode <> 'drk'";
     }      
}
	
class clsKlanten extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $column = new clsColumn();
          $column->setFieldName("klantnaam");
          $column->setCaption("Naam");         
          $this->columnHeader->addColumn($column);

          $column = new clsColumn();
          $column->setFieldName("telefoon");
          $column->setCaption("Telefoon");         
          $column->setEditType("Telephone");
          $this->columnHeader->addColumn($column);

          $column = new clsColumn();
          $column->setFieldName("email");
          $column->setCaption("Email");         
          $this->columnHeader->addColumn($column);
          
          $this->selectsql = "SELECT * FROM klant ORDER BY klantnaam"; 
          $this->tablename = "klant";
          $this->key = "klant_id";
     }  
     
     // Toegevoegd n.a.v. ticketnummer [[342]]
     protected function checkBeforeSave($values) 
     {    $message = "";
          if ($values['klantnaam'] === "")
          {    $message .= "Vul minstens de klantnaam in.<br>";
          }
          if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL))
          {  $message .= "Onjuist emailadres.<br>"; 
          }
          if ($message == "")
          {    return true;
          }
          $this->setLastmessage($message);
          return false;
     }
     // Einde oegevoegd n.a.v. ticketnummer [[342]]
    
     // Toegevoegd n.a.v. ticketnummer [[324]]
     protected function checkBeforeDelete() 
     {
          $sql = "SELECT COUNT(*) 
                    FROM bestelling b
                    LEFT JOIN reservering r 
                           ON b.reservering_id = b.reservering_id 
                   WHERE r.klant_id = " . $this->getKeyValue();
          if ($this->connection->query($sql)->fetchColumn() > 0)
          {    $this->setLastmessage("Er zijn nog bestellingen voor deze klant.<br>" .
                                     "Deze klant mag daarom niet worden verwijderd.");
               return false;
          }
          return true;
     }
     // Einde toegevoegd n.a.v. ticketnummer [[324]]

}

class clsSubGerechten extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT subgerechtcode, subgerechtnaam, gerechtcode
                                FROM subgerecht
                              ORDER BY subgerechtnaam";
          $this->tablename = "subgerecht";
          $this->key = "subgerechtcode";
          
          $column = new clsColumn();
          $column->setFieldName("subgerechtcode");
          $column->setCaption("Code");
          $column->setReadOnly();
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("subgerechtnaam");
          $column->setCaption("Omschrijving");         
          $this->columnHeader->addColumn($column);         
          
          $column = new clsColumn();
          $column->setFieldName("gerechtcode");
          $column->setCaption("Valt onder");
          $column->setEditType("Select");
          $column->setLookUpSql("SELECT gerechtnaam as lookupresult, gerechtcode as lookup_id
                                   FROM gerecht 
                                 ORDER BY gerechtnaam");
          $this->columnHeader->addColumn($column);         
     }  
}

class clsGerechten extends clsTableDef
{     
     public function __construct() 
     {
          parent::__construct();
          
          $this->selectsql = "SELECT gerechtcode, gerechtnaam 
                                FROM gerecht
                              ORDER BY gerechtnaam"; 
          $this->tablename = "gerecht";
          $this->key = "gerechtcode";
          
          $column = new clsColumn();
          $column->setFieldName("gerechtcode");
          $column->setCaption("Code");
          $column->setReadOnly();
          $this->columnHeader->addColumn($column);
          
          $column = new clsColumn();
          $column->setFieldName("gerechtnaam");
          $column->setCaption("Omschrijving");         
          $this->columnHeader->addColumn($column);                   
     }  
}

class clsPage extends clsDefaultPage
{	
     protected function contentHtml() 
     {	
          $datalist = null;
          $soort = "";		
          if (isset($_GET['soort'])) 
          {    $soort = $_GET['soort'];
               $keyvalue = false;		
               if (isset($_GET['key'])) 
               {    $keyvalue = $_GET['key'];
               }  
               $datalist = $this->getTableDef($soort, $keyvalue);
          }
          else
          {    return "Onbekend gegeven.";
          }
          
          $action = "";		
          if (isset($_GET['action'])) 
          {    $action = $_GET['action'];
          }

          switch($action) 
          {
               case "edit": 
                    return $datalist->getEditHtml(); break;
               case "new": 
                    return $datalist->getNewHtml(); break;
               case "save": 
                    return $datalist->getUpdateHtml(); break;
               case "insert": 
                    return $datalist->getInsertHtml(); break;
               case "confirmdelete": 
                    return $datalist->getConfirmDeleteHtml(); break; // Toegevoegd n.a.v. ticketnummer [[328]]
               case "delete": 
                    return $datalist->getDeleteHtml(); break;
               default:   
                    return $datalist->getGridHtml(); break;
          }  
          
     } 
     
     protected function getTableDef($soort, $keyvalue) 
     {
          $datalist = false;
          switch($soort) 
          {
               case "drinken"     : $datalist = new clsDrinken(); break;
               case "eten"        : $datalist = new clsEten(); break;
               case "klanten"     : $datalist = new clsKlanten(); break;
               case "gerechten"   : $datalist = new clsGerechten(); break;
               case "subgerechten": $datalist = new clsSubgerechten(); break;
          }
          if (!$datalist)
          {
               print "Onbekend gegeven.";
               die;
          }        
          $datalist->setSoort($soort);
          $datalist->setKeyValue($keyvalue);
          
          return $datalist;
     }    
}

     $page = new clsPage();
	echo $page->getHtml();
?>